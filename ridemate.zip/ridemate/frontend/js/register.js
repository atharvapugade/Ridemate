document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('registerForm');

  if (form) {
    form.addEventListener('submit', async function (e) {
      e.preventDefault();

      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value.trim();
      const address = document.getElementById('address').value.trim();
      const phone = document.getElementById('phone').value.trim();
      const msgElement = document.getElementById('registerMsg');

      try {
        const response = await fetch('http://localhost:5000/api/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password, address, phone }),
        });

        const data = await response.json();

        if (response.ok) {
          msgElement.style.color = '#00e6e6';
          msgElement.innerText = data.msg || 'Registration successful! Redirecting to login...';
          form.reset();

          setTimeout(() => {
            window.location.href = 'login.html';
          }, 2000);
        } else {
          msgElement.style.color = 'red';
          msgElement.innerText = data.msg || 'Registration failed!';
        }
      } catch (err) {
        console.error('Error:', err);
        msgElement.style.color = 'red';
        msgElement.innerText = 'Something went wrong';
      }
    });
  }
});
