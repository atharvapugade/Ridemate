// controllers/bookingController.js

const Booking = require('../models/booking');
const Ride = require('../models/ride');

exports.bookRide = async (req, res) => {
  try {
    const { rideId, passengerName, passengerEmail, seatsBooked } = req.body;

    if (!rideId || !passengerName || !passengerEmail || !seatsBooked) {
      return res.status(400).json({ msg: 'All booking details are required' });
    }

    const ride = await Ride.findById(rideId);

    if (!ride) {
      return res.status(404).json({ msg: 'Ride not found' });
    }

    if (ride.seatsAvailable < seatsBooked) {
      return res.status(400).json({ msg: 'Not enough seats available' });
    }

    // Create booking
    const booking = await Booking.create({
      ride: ride._id,
      passengerName,
      passengerEmail,
      seatsBooked,
    });

    // Update available seats
    ride.seatsAvailable -= seatsBooked;
    await ride.save();

    // Placeholder for notification
    console.log(`📢 Notify: ${ride.name} (ride uploader) – someone booked your ride!`);

    res.status(201).json({ msg: 'Ride booked successfully!', booking });

  } catch (err) {
    console.error('🔴 Booking Error:', err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// Fetch bookings by user email
exports.getUserBookings = async (req, res) => {
  try {
    const { email } = req.query;

    if (!email) {
      return res.status(400).json({ msg: 'User email is required' });
    }

    const bookings = await Booking.find({ passengerEmail: email }).populate('ride');

    res.status(200).json({ bookings });
  } catch (err) {
    console.error('Fetch Bookings Error:', err.message);
    res.status(500).json({ msg: 'Server error while fetching bookings' });
  }
};

