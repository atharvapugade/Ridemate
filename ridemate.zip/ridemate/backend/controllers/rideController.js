const Ride = require('../models/ride');

exports.uploadRide = async (req, res) => {
  try {
    const { name, pickupLocation, dropLocation, date, seatsAvailable, isWomenOnly } = req.body;

    if (!name || !pickupLocation || !dropLocation || !date || !seatsAvailable) {
      return res.status(400).json({ msg: 'Please fill all ride details' });
    }

    const ride = new Ride({
      name,
      pickupLocation,
      dropLocation,
      date,
      seatsAvailable,
      isWomenOnly,
      createdBy: req.userId || null  // Optional: if you're using JWT auth
    });

    await ride.save();
    res.status(201).json({ msg: 'Ride uploaded successfully' });

  } catch (err) {
    console.error('🔴 Ride Upload Error:', err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};


exports.findRides = async (req, res) => {
    try {
      const { pickupLocation, dropLocation, date, seatsRequired, isWomenOnly } = req.body;
  
      if (!pickupLocation || !dropLocation || !date || !seatsRequired) {
        return res.status(400).json({ msg: 'Please provide all required fields' });
      }
  
      // Build search criteria dynamically
      const criteria = {
        pickupLocation,
        dropLocation,
        date: new Date(date),
        seatsAvailable: { $gte: parseInt(seatsRequired) },
      };
  
      if (isWomenOnly === true || isWomenOnly === 'true') {
        criteria.isWomenOnly = true;
      }
  
      const rides = await Ride.find(criteria);
      res.status(200).json({ rides });
  
    } catch (err) {
      console.error('🔴 Find Ride Error:', err.message);
      res.status(500).json({ msg: 'Server error' });
    }
  };
  