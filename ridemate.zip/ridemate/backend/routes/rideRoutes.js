const express = require('express');
const router = express.Router();
const { uploadRide,findRides } = require('../controllers/rideController');

router.post('/upload', uploadRide);
router.post('/find', findRides);

module.exports = router;
