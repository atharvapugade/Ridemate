const express = require('express');
const router = express.Router();
const { bookRide, getUserBookings } = require('../controllers/bookingController');

// Book a ride
router.post('/', bookRide);

// Get bookings by user
router.get('/', getUserBookings);

module.exports = router;
