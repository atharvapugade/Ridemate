const Booking = require('../models/booking');
const Ride = require('../models/ride');
const User = require('../models/user');
const sendEmail = require('../utils/sendEmail');

// ✅ Book a Ride
exports.bookRide = async (req, res) => {
  try {
    const { rideId, passengerName, passengerEmail, seatsBooked } = req.body;

    if (!rideId || !passengerName || !passengerEmail || !seatsBooked) {
      return res.status(400).json({ msg: 'All booking details are required' });
    }

    const ride = await Ride.findById(rideId).populate('createdBy');
    if (!ride) {
      return res.status(404).json({ msg: 'Ride not found' });
    }

    if (ride.seatsAvailable < seatsBooked) {
      return res.status(400).json({ msg: 'Not enough seats available' });
    }

    // Create booking
    const booking = await Booking.create({
      ride: ride._id,
      passengerName,
      passengerEmail,
      seatsBooked,
    });

    // Update ride seats
    ride.seatsAvailable -= seatsBooked;
    await ride.save();

    // 🔍 Fetch passenger's phone number
    const passenger = await User.findOne({ email: passengerEmail });
    const passengerPhone = passenger?.phone || 'Not provided';

    // 📧 Email notification to uploader
    if (ride.createdBy?.email) {
      const uploaderEmail = ride.createdBy.email;
      const uploaderName = ride.createdBy.name || "RideMate User";

      const subject = `🚨 Your Ride Has Been Booked`;
      const message = `
Hello ${uploaderName},

Your ride from ${ride.pickupLocation} to ${ride.dropLocation} on ${new Date(ride.date).toDateString()} has been booked.

👤 Passenger Details:
- Name: ${passengerName}
- Email: ${passengerEmail}
- Phone: ${passengerPhone}
- Seats Booked: ${seatsBooked}

Please get in touch with the passenger to coordinate further.

Thanks,  
RideMate Team
      `;

      await sendEmail(uploaderEmail, subject, message);
    }

    res.status(201).json({ msg: 'Ride booked and notification sent!', booking });

  } catch (err) {
    console.error('🔴 Booking Error:', err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// ✅ Get Bookings for a User by Email
exports.getUserBookings = async (req, res) => {
  try {
    const { email } = req.query;

    if (!email) {
      return res.status(400).json({ msg: 'User email is required' });
    }

    const bookings = await Booking.find({ passengerEmail: email }).populate('ride');

    res.status(200).json({ bookings });
  } catch (err) {
    console.error('Fetch Bookings Error:', err.message);
    res.status(500).json({ msg: 'Server error while fetching bookings' });
  }
};
