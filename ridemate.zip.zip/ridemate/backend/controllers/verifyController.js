const fs = require('fs');
const xml2js = require('xml2js');
const User = require('../models/user');

// 📥 Aadhaar XML Upload
exports.verifyGenderFromAadhaar = async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ msg: 'No file uploaded' });

    const xml = fs.readFileSync(req.file.path, 'utf-8');
    const parser = new xml2js.Parser();

    parser.parseString(xml, async (err, result) => {
      if (err) return res.status(400).json({ msg: 'Invalid XML' });

      const gender = result?.OfflinePaperlessKyc?.UidData?.[0]?.Poi?.[0]?.$.gender;

      if (!['M', 'F', 'O'].includes(gender)) {
        return res.status(400).json({ msg: 'Gender not found in XML' });
      }

      const user = await User.findById(req.user._id);
      user.gender = gender;
      user.genderVerified = true;
      await user.save();

      res.status(200).json({ msg: 'Gender verified successfully', gender });
    });
  } catch (err) {
    console.error('🔴 Aadhaar Verify Error:', err.message);
    res.status(500).json({ msg: 'Server error during Aadhaar gender verification' });
  }
};
