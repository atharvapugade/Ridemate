const Ride = require('../models/ride');

// ✅ Upload Ride (Requires Auth)
exports.uploadRide = async (req, res) => {
  try {
    const { name, pickupLocation, dropLocation, date, seatsAvailable, isWomenOnly } = req.body;

    if (!name || !pickupLocation || !dropLocation || !date || !seatsAvailable) {
      return res.status(400).json({ msg: 'Please fill all ride details' });
    }

    // 🚫 Restrict women-only rides to Aadhaar-verified female users
    if ((isWomenOnly === true || isWomenOnly === 'true') && (!req.user || req.user.gender !== 'F' || !req.user.genderVerified)) {
      return res.status(403).json({
        msg: 'Only Aadhaar-verified female users can offer women-only rides.',
      });
    }

    const ride = new Ride({
      name,
      pickupLocation,
      dropLocation,
      date,
      seatsAvailable,
      isWomenOnly,
      createdBy: req.user._id,
    });

    await ride.save();
    res.status(201).json({ msg: 'Ride uploaded successfully' });

  } catch (err) {
    console.error('🔴 Ride Upload Error:', err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// ✅ Find Rides (No Auth Needed)
exports.findRides = async (req, res) => {
  try {
    const { pickupLocation, dropLocation, date, seatsRequired, isWomenOnly } = req.body;

    if (!pickupLocation || !dropLocation || !date || !seatsRequired) {
      return res.status(400).json({ msg: 'Please provide all required fields' });
    }

    const criteria = {
      pickupLocation,
      dropLocation,
      date: new Date(date),
      seatsAvailable: { $gte: parseInt(seatsRequired) },
    };

    if (isWomenOnly === true || isWomenOnly === 'true') {
      criteria.isWomenOnly = true;
    }

    const rides = await Ride.find(criteria);
    res.status(200).json({ rides });

  } catch (err) {
    console.error('🔴 Find Ride Error:', err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};
