const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Optional: serve uploaded files if needed (like Aadhaar XML)
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/rides', require('./routes/rideRoutes'));
app.use('/api/bookings', require('./routes/bookingRoutes'));
app.use('/api/verify', require('./routes/verifyRoutes')); // ✅ Gender verification (Aadhaar)

// Health Check Route
app.get('/', (req, res) => {
  res.send('🚗 RideMate Backend is Up and Running');
});

module.exports = app;
