const express = require('express');
const router = express.Router();
const { uploadRide, findRides } = require('../controllers/rideController');
const auth = require('../middleware/auth'); // ✅ Import the middleware

router.post('/upload', auth, uploadRide);   // ✅ Protect this route
router.post('/find', findRides);            // Public

module.exports = router;
