const express = require('express');
const router = express.Router();
const { registerUser, loginUser } = require('../controllers/authController');
const auth = require('../middleware/auth'); // ✅ Auth middleware
const User = require('../models/user');     // ✅ User model

// @route   POST /api/auth/register
router.post('/register', registerUser);

// @route   POST /api/auth/login
router.post('/login', loginUser);

// ✅ @route   GET /api/auth/me
// ✅ @desc    Get current user info using JWT token
// ✅ @access  Private
router.get('/me', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('-password');
    if (!user) return res.status(404).json({ msg: 'User not found' });

    res.json({ user });
  } catch (err) {
    console.error('🔴 /me Route Error:', err.message);
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;
