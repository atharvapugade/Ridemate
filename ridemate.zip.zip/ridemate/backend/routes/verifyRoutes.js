const express = require('express');
const multer = require('multer');
const router = express.Router();
const auth = require('../middleware/auth');
const { verifyGenderFromAadhaar } = require('../controllers/verifyController');

const upload = multer({ dest: 'uploads/' });

router.post('/aadhaar-upload', auth, upload.single('aadhaarXml'), verifyGenderFromAadhaar);

module.exports = router;
