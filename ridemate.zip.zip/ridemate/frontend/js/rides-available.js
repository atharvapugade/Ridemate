document.addEventListener('DOMContentLoaded', async () => {
  const rideData = JSON.parse(localStorage.getItem('rideSearchData'));
  const ridesList = document.getElementById('ridesList');

  if (!rideData) {
    window.location.href = 'find-ride.html';
    return;
  }

  console.log("📤 Sending search data to backend:", rideData);

  try {
    const response = await fetch('http://localhost:5000/api/rides/find', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(rideData)
    });

    const result = await response.json();
    console.log("📥 Response from backend:", result);

    if (response.ok && result.rides && result.rides.length > 0) {
      ridesList.innerHTML = '';

      result.rides.forEach(ride => {
        const card = document.createElement('div');
        card.className = 'ride-card';

        card.innerHTML = `
          <p><strong>Driver:</strong> ${ride.name}</p>
          <p><strong>From:</strong> ${ride.pickupLocation}</p>
          <p><strong>To:</strong> ${ride.dropLocation}</p>
          <p><strong>Date:</strong> ${new Date(ride.date).toDateString()}</p>
          <p><strong>Seats Available:</strong> ${ride.seatsAvailable}</p>
          <p><strong>Women Only:</strong> ${ride.isWomenOnly ? 'Yes' : 'No'}</p>
          <label>Seats to Book:
            <input type="number" min="1" max="${ride.seatsAvailable}" value="1" id="seats-${ride._id}" />
          </label>
          <button class="book-btn" data-rideid="${ride._id}">Book Now</button>
        `;

        ridesList.appendChild(card);
      });

      document.querySelectorAll('.book-btn').forEach(button => {
        button.addEventListener('click', async () => {
          const rideId = button.getAttribute('data-rideid');
          const passengerName = localStorage.getItem('userName');
          const passengerEmail = localStorage.getItem('userEmail');
          const seatsInput = document.getElementById(`seats-${rideId}`);
          const seatsBooked = parseInt(seatsInput.value);

          if (!passengerName || !passengerEmail) {
            alert('⚠️ You must be logged in to book a ride.');
            return;
          }

          try {
            const bookingResponse = await fetch('http://localhost:5000/api/bookings', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ rideId, passengerName, passengerEmail, seatsBooked })
            });

            const bookingResult = await bookingResponse.json();

            if (bookingResponse.ok) {
              alert('✅ Ride booked successfully!');
              seatsInput.max = parseInt(seatsInput.max) - seatsBooked;
            } else {
              alert(`❌ ${bookingResult.msg}`);
            }
          } catch (err) {
            console.error('Booking Error:', err);
            alert('Something went wrong while booking. Please try again later.');
          }
        });
      });

    } else {
      window.location.href = 'no-rides.html';
    }

  } catch (error) {
    console.error('❌ Error fetching rides:', error);
    window.location.href = 'no-rides.html';
  }
});
