document.addEventListener('DOMContentLoaded', () => {
  console.log("✅ login.js loaded");

  const loginForm = document.getElementById('loginForm');

  if (!loginForm) {
    console.error("❌ loginForm not found in the DOM");
    return;
  }

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    const msg = document.getElementById('loginMsg');

    try {
      const res = await fetch('http://localhost:5000/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
      });

      const data = await res.json();
      console.log("📥 Response from backend:", data);

      if (res.ok && data.token && data.user) {
        localStorage.setItem('token', data.token);
        localStorage.setItem('userEmail', data.user?.email || '');
        localStorage.setItem('userName', data.user?.name || 'User');

        msg.style.color = '#00e6e6';
        msg.textContent = 'Login successful! Redirecting...';

        alert(`Welcome back to RideMate, ${data.user?.name || 'User'}!`);

        setTimeout(() => {
          window.location.href = 'dashboard.html';
        }, 1500);
      } else {
        msg.style.color = 'red';
        msg.textContent = data.message || 'Login failed. Please try again.';
      }
    } catch (error) {
      console.error('❌ Login error:', error);
      msg.style.color = 'red';
      msg.textContent = 'Something went wrong. Please try again later.';
    }
  });
});
