document.addEventListener('DOMContentLoaded', () => {
  mapboxgl.accessToken = 'pk.eyJ1IjoiYXRoYXJ2MTIiLCJhIjoiY205NXR6djhyMWF1YTJtczVhbGtxeXM4eSJ9.C018-f97TTYkNg7t7UN4aA';

 
  
    let pickupLocation = '';
    let dropLocation = '';
  
    const pickupGeocoder = new MapboxGeocoder({
      accessToken: mapboxgl.accessToken,
      placeholder: 'Pickup Location',
      mapboxgl: mapboxgl,
      marker: false
    });
    pickupGeocoder.addTo('#pickup');
    pickupGeocoder.on('result', e => pickupLocation = e.result.place_name);
  
    const dropGeocoder = new MapboxGeocoder({
      accessToken: mapboxgl.accessToken,
      placeholder: 'Drop Location',
      mapboxgl: mapboxgl,
      marker: false
    });
    dropGeocoder.addTo('#drop');
    dropGeocoder.on('result', e => dropLocation = e.result.place_name);
  
    const form = document.getElementById('findRideForm');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
  
      const dateInput = document.getElementById('date').value;
      const seats = parseInt(document.getElementById('seats').value);
      const womenOnly = document.getElementById('womenOnly').checked;
  
      if (!pickupLocation || !dropLocation || !dateInput || isNaN(seats)) {
        document.getElementById('findMsg').innerText = 'All fields are required.';
        return;
      }
  
      const searchData = {
        pickupLocation,
        dropLocation,
        date: dateInput,
        seatsRequired: seats,
        isWomenOnly: womenOnly
      };
  
      localStorage.setItem('rideSearchData', JSON.stringify(searchData));
      window.location.href = 'rides-available.html';
    });
  });
  